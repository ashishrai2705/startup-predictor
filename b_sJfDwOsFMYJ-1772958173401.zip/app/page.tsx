import Link from "next/link"
import { ArrowRight, Sparkles, TrendingUp, Target, Brain, BarChart3, Zap, Github, Mail, Info } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-foreground" />
            </div>
            <span className="font-semibold text-lg text-foreground">StartupPredictor</span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Dashboard
            </Link>
            <Link href="/predict" className="text-muted-foreground hover:text-foreground transition-colors">
              Predict
            </Link>
            <Link href="/analytics" className="text-muted-foreground hover:text-foreground transition-colors">
              Analytics
            </Link>
          </div>
          <Button asChild variant="outline" className="border-primary/50 hover:bg-primary/10">
            <Link href="/dashboard">
              Get Started
            </Link>
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-gradient-to-b from-purple-500/30 via-blue-500/20 to-transparent rounded-full blur-3xl opacity-50" />
        
        <div className="max-w-5xl mx-auto text-center relative">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-muted-foreground">AI-Powered Startup Analysis</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight text-balance">
            <span className="gradient-text">Predict Startup Success</span>
            <br />
            <span className="text-foreground">with AI</span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed text-pretty">
            Analyze funding, team strength, and market signals to estimate startup growth potential using machine learning.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button asChild size="lg" className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-foreground px-8 py-6 text-lg rounded-xl shadow-lg shadow-purple-500/25 transition-all hover:shadow-purple-500/40 hover:scale-105">
              <Link href="/predict">
                Try the Predictor
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="border-border/50 hover:bg-secondary/50 px-8 py-6 text-lg rounded-xl transition-all hover:scale-105">
              <Link href="/dashboard">
                View Dashboard Demo
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">Powerful Features</h2>
            <p className="text-muted-foreground text-lg">Everything you need to analyze startup potential</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="glass-card rounded-2xl p-8 hover:border-purple-500/30 transition-all duration-300 hover:-translate-y-1 group">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-purple-500/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Brain className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-foreground">AI-Powered Analysis</h3>
              <p className="text-muted-foreground leading-relaxed">
                Advanced machine learning models trained on thousands of startup success patterns.
              </p>
            </div>
            
            <div className="glass-card rounded-2xl p-8 hover:border-blue-500/30 transition-all duration-300 hover:-translate-y-1 group">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/20 to-blue-500/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <TrendingUp className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-foreground">Growth Signal Insights</h3>
              <p className="text-muted-foreground leading-relaxed">
                Deep analysis of funding patterns, team dynamics, and market positioning.
              </p>
            </div>
            
            <div className="glass-card rounded-2xl p-8 hover:border-indigo-500/30 transition-all duration-300 hover:-translate-y-1 group">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500/20 to-indigo-500/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Target className="w-6 h-6 text-indigo-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-foreground">Success Predictions</h3>
              <p className="text-muted-foreground leading-relaxed">
                Probability-based predictions with confidence intervals and risk assessment.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-6 relative">
        <div className="absolute inset-0 animated-gradient opacity-30" />
        
        <div className="max-w-6xl mx-auto relative">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">How It Works</h2>
            <p className="text-muted-foreground text-lg">Three simple steps to predict startup success</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/30">
                <span className="text-2xl font-bold text-foreground">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-3 text-foreground">Enter Startup Details</h3>
              <p className="text-muted-foreground">
                Input key metrics like funding, team size, industry, and growth indicators.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-500/30">
                <span className="text-2xl font-bold text-foreground">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-3 text-foreground">AI Analyzes Data</h3>
              <p className="text-muted-foreground">
                Our ML model processes your data against thousands of success patterns.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-600 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-indigo-500/30">
                <span className="text-2xl font-bold text-foreground">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-3 text-foreground">Get Insights</h3>
              <p className="text-muted-foreground">
                Receive success probability, risk assessment, and actionable recommendations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="glass-card rounded-3xl p-12 text-center purple-glow">
            <Zap className="w-12 h-12 text-purple-400 mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">Ready to Predict Success?</h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto">
              Start analyzing your startup potential with our AI-powered prediction tool.
            </p>
            <Button asChild size="lg" className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-foreground px-10 py-6 text-lg rounded-xl shadow-lg shadow-purple-500/25 transition-all hover:shadow-purple-500/40 hover:scale-105">
              <Link href="/predict">
                Get Started Free
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-border/50">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-foreground" />
              </div>
              <span className="font-semibold text-foreground">StartupPredictor</span>
            </div>
            
            <div className="flex items-center gap-8">
              <Link href="/about" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <Info className="w-4 h-4" />
                About
              </Link>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <Github className="w-4 h-4" />
                GitHub
              </a>
              <a href="mailto:contact@example.com" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <Mail className="w-4 h-4" />
                Contact
              </a>
            </div>
          </div>
          
          <div className="mt-8 text-center text-sm text-muted-foreground">
            <p>2026 StartupPredictor. Built with AI.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
