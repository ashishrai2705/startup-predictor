"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sparkles, DollarSign, Users, Building2, Calendar, Target, Flag } from "lucide-react"

const industries = [
  "Technology",
  "Healthcare",
  "Finance",
  "E-commerce",
  "Education",
  "Energy",
  "Real Estate",
  "Manufacturing",
  "Entertainment",
  "Transportation",
]

export default function PredictPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    fundingAmount: "",
    teamSize: "",
    industry: "",
    yearsActive: "",
    fundingRounds: "",
    milestonesAchieved: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Store form data and navigate to results
    const params = new URLSearchParams({
      funding: formData.fundingAmount,
      team: formData.teamSize,
      industry: formData.industry,
      years: formData.yearsActive,
      rounds: formData.fundingRounds,
      milestones: formData.milestonesAchieved,
    })
    
    router.push(`/results?${params.toString()}`)
  }

  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-4">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-muted-foreground">AI-Powered Prediction</span>
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-3">Predict Startup Success</h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Enter your startup details below and our AI model will analyze the data to predict success probability.
          </p>
        </div>

        {/* Prediction Form */}
        <form onSubmit={handleSubmit} className="glass-card rounded-3xl p-8 space-y-8">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Funding Amount */}
            <div className="space-y-2">
              <Label htmlFor="funding" className="text-foreground flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-purple-400" />
                Funding Amount (USD)
              </Label>
              <Input
                id="funding"
                type="number"
                placeholder="e.g., 5000000"
                value={formData.fundingAmount}
                onChange={(e) => setFormData({ ...formData, fundingAmount: e.target.value })}
                className="bg-input border-border/50 focus:border-purple-500/50 h-12 rounded-xl"
                required
              />
            </div>

            {/* Team Size */}
            <div className="space-y-2">
              <Label htmlFor="team" className="text-foreground flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-400" />
                Team Size
              </Label>
              <Input
                id="team"
                type="number"
                placeholder="e.g., 25"
                value={formData.teamSize}
                onChange={(e) => setFormData({ ...formData, teamSize: e.target.value })}
                className="bg-input border-border/50 focus:border-purple-500/50 h-12 rounded-xl"
                required
              />
            </div>

            {/* Industry */}
            <div className="space-y-2">
              <Label htmlFor="industry" className="text-foreground flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-400" />
                Industry
              </Label>
              <Select
                value={formData.industry}
                onValueChange={(value) => setFormData({ ...formData, industry: value })}
                required
              >
                <SelectTrigger className="bg-input border-border/50 focus:border-purple-500/50 h-12 rounded-xl">
                  <SelectValue placeholder="Select industry" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {industries.map((industry) => (
                    <SelectItem key={industry} value={industry.toLowerCase()}>
                      {industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Years Active */}
            <div className="space-y-2">
              <Label htmlFor="years" className="text-foreground flex items-center gap-2">
                <Calendar className="w-4 h-4 text-green-400" />
                Years Active
              </Label>
              <Input
                id="years"
                type="number"
                placeholder="e.g., 3"
                value={formData.yearsActive}
                onChange={(e) => setFormData({ ...formData, yearsActive: e.target.value })}
                className="bg-input border-border/50 focus:border-purple-500/50 h-12 rounded-xl"
                required
              />
            </div>

            {/* Funding Rounds */}
            <div className="space-y-2">
              <Label htmlFor="rounds" className="text-foreground flex items-center gap-2">
                <Target className="w-4 h-4 text-orange-400" />
                Funding Rounds
              </Label>
              <Input
                id="rounds"
                type="number"
                placeholder="e.g., 2"
                value={formData.fundingRounds}
                onChange={(e) => setFormData({ ...formData, fundingRounds: e.target.value })}
                className="bg-input border-border/50 focus:border-purple-500/50 h-12 rounded-xl"
                required
              />
            </div>

            {/* Milestones Achieved */}
            <div className="space-y-2">
              <Label htmlFor="milestones" className="text-foreground flex items-center gap-2">
                <Flag className="w-4 h-4 text-pink-400" />
                Milestones Achieved
              </Label>
              <Input
                id="milestones"
                type="number"
                placeholder="e.g., 5"
                value={formData.milestonesAchieved}
                onChange={(e) => setFormData({ ...formData, milestonesAchieved: e.target.value })}
                className="bg-input border-border/50 focus:border-purple-500/50 h-12 rounded-xl"
                required
              />
            </div>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-14 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-foreground text-lg rounded-xl shadow-lg shadow-purple-500/25 transition-all hover:shadow-purple-500/40 disabled:opacity-50"
          >
            {isLoading ? (
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 border-2 border-foreground/30 border-t-foreground rounded-full animate-spin" />
                Analyzing with AI...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Predict Startup Success
              </div>
            )}
          </Button>
        </form>

        {/* Info Cards */}
        <div className="grid md:grid-cols-3 gap-4 mt-8">
          <div className="glass-card rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground mb-1">95%</p>
            <p className="text-sm text-muted-foreground">Model Accuracy</p>
          </div>
          <div className="glass-card rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground mb-1">10K+</p>
            <p className="text-sm text-muted-foreground">Startups Analyzed</p>
          </div>
          <div className="glass-card rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground mb-1">{"<"}2s</p>
            <p className="text-sm text-muted-foreground">Analysis Time</p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
